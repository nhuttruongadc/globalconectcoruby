import { useEffect, useState } from "react";
import { motion, useScroll, useSpring } from "framer-motion";
import Header from "./components/Header";
import Hero from "./components/Hero";
import Story from "./components/Story";
import Courses from "./components/Courses";
import Method from "./components/Method";
import Achievements from "./components/Achievements";
import Founder from "./components/Founder";
import Facilities from "./components/Facilities";
import Contact from "./components/Contact";
import Footer from "./components/Footer";

function ScrollProgress() {
  const { scrollYProgress } = useScroll();
  const scaleX = useSpring(scrollYProgress, { stiffness: 120, damping: 25, restDelta: 0.001 });
  return (
    <motion.div
      style={{ scaleX }}
      className="fixed inset-x-0 top-0 z-[60] h-1 origin-left bg-gradient-to-r from-ruby-500 via-rose-400 to-ruby-600"
    />
  );
}

function BackToTop() {
  const [show, setShow] = useState(false);
  useEffect(() => {
    const fn = () => setShow(window.scrollY > 600);
    window.addEventListener("scroll", fn, { passive: true });
    return () => window.removeEventListener("scroll", fn);
  }, []);

  return (
    <motion.a
      href="#top"
      initial={false}
      animate={{ opacity: show ? 1 : 0, scale: show ? 1 : 0.5, y: show ? 0 : 20 }}
      transition={{ duration: 0.3 }}
      whileHover={{ scale: 1.15 }}
      whileTap={{ scale: 0.9 }}
      aria-label="Lên đầu trang"
      className={`fixed right-6 bottom-6 z-50 grid h-13 w-13 place-items-center rounded-full bg-gradient-to-br from-ruby-500 to-ruby-700 p-3.5 text-xl text-white shadow-xl shadow-ruby-600/40 transition-opacity ${
        show ? "" : "pointer-events-none"
      }`}
    >
      ↑
    </motion.a>
  );
}

export default function App() {
  return (
    <div className="min-h-screen">
      <ScrollProgress />
      <Header />
      <main>
        <Hero />
        <Story />
        <Courses />
        <Method />
        <Achievements />
        <Founder />
        <Facilities />
        <Contact />
      </main>
      <Footer />
      <BackToTop />
    </div>
  );
}
