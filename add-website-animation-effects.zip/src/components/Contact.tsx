import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Reveal, SectionHead, Sparkles } from "./shared";

const info = [
  { icon: "📞", label: "Điện Thoại / Zalo", value: "0344 878 674", href: "tel:0344878674" },
  { icon: "📍", label: "Địa Chỉ", value: "Khu vực Chi Lăng, Tịnh Biên, An Giang" },
  { icon: "🕐", label: "Thời Gian", value: "Lịch học linh hoạt — liên hệ để đặt lịch" },
  { icon: "👥", label: "Đối Tượng", value: "Học sinh từ 4 tuổi trở lên" },
];

const ZALO_PHONE = "0344878674";

// Detect phone/tablet so we can show the right paste instructions.
const isMobileDevice = () =>
  typeof navigator !== "undefined" && /Android|iPhone|iPad|iPod/i.test(navigator.userAgent);

export default function Contact() {
  const [sent, setSent] = useState(false);
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [lastMessage, setLastMessage] = useState("");
  const [isMobile, setIsMobile] = useState(false);
  const [copyOk, setCopyOk] = useState<boolean | null>(null);
  const [copiedAgain, setCopiedAgain] = useState(false);

  const copyMessage = async (text: string) => {
    try {
      await navigator.clipboard.writeText(text);
      return true;
    } catch {
      return false;
    }
  };

  return (
    <section id="contact" className="relative overflow-hidden bg-gradient-to-br from-ruby-100 via-rose-50 to-rose-100 py-24">
      <div className="pointer-events-none absolute -top-24 left-1/4 h-96 w-96 rounded-full bg-ruby-300/60 blur-[110px]" />
      <Sparkles count={14} />

      <div className="relative mx-auto max-w-7xl px-5 lg:px-8">
        <SectionHead
          kicker="Thông Tin Liên Hệ"
          title="Kết Nối Với Chúng Tôi"
          sub="Đừng ngại liên hệ — chúng tôi luôn sẵn sàng đồng hành cùng hành trình học ngôn ngữ của bạn và gia đình."
        />

        <div className="grid gap-10 lg:grid-cols-2">
          {/* Info cards */}
          <div className="space-y-5">
            {info.map((c, i) => (
              <Reveal key={c.label} delay={i * 0.1}>
                <motion.a
                  href={c.href ?? undefined}
                  whileHover={c.href ? { x: 10, scale: 1.02 } : { x: 10 }}
                  transition={{ type: "spring", stiffness: 300 }}
                  className="group flex items-center gap-5 rounded-3xl bg-white/80 p-5 ring-1 ring-ruby-100 backdrop-blur transition-colors duration-300 hover:bg-white hover:ring-ruby-300"
                >
                  <span className="grid h-14 w-14 shrink-0 place-items-center rounded-2xl bg-gradient-to-br from-ruby-400 to-rose-500 text-2xl shadow-lg shadow-ruby-500/30 transition-transform duration-500 group-hover:rotate-12 group-hover:scale-110">
                    {c.icon}
                  </span>
                  <div>
                    <p className="text-xs font-bold tracking-widest text-ruby-500 uppercase">{c.label}</p>
                    <p className="mt-1 text-lg font-bold text-ruby-950">{c.value}</p>
                  </div>
                </motion.a>
              </Reveal>
            ))}

            <Reveal delay={0.45}>
              <a
                href="https://zalo.me/0344878674"
                target="_blank"
                rel="noreferrer"
                className="group flex items-center justify-center gap-3 rounded-3xl bg-[#0068ff] px-6 py-5 text-lg font-bold text-white shadow-xl shadow-blue-900/30 transition-all duration-300 hover:scale-[1.02] hover:shadow-2xl"
              >
                <span className="text-2xl">💬</span> Nhắn Tin Zalo Ngay
                <span className="transition-transform duration-300 group-hover:translate-x-1.5">→</span>
              </a>
            </Reveal>
          </div>

          {/* Form */}
          <Reveal delay={0.2}>
            <div className="rounded-[2rem] bg-white p-8 shadow-2xl shadow-ruby-900/15 sm:p-10">
              <AnimatePresence mode="wait">
                {sent ? (
                  <motion.div
                    key="ok"
                    initial={{ opacity: 0, scale: 0.85 }}
                    animate={{ opacity: 1, scale: 1 }}
                    className="flex h-full min-h-[380px] flex-col items-center justify-center text-center"
                  >
                    <motion.span
                      initial={{ scale: 0, rotate: -30 }}
                      animate={{ scale: 1, rotate: 0 }}
                      transition={{ type: "spring", stiffness: 200, delay: 0.15 }}
                      className="grid h-24 w-24 place-items-center rounded-full bg-green-100 text-5xl"
                    >
                      ✅
                    </motion.span>
                    <h3 className="mt-6 font-display text-2xl font-bold text-ruby-950">Gần xong rồi! Chỉ còn 1 bước nữa</h3>
                    <p className="mt-2 max-w-sm text-sm text-ruby-950/60">
                      {copyOk === false
                        ? "Cửa sổ Zalo với cô Ruby vừa mở ra. Trình duyệt không tự sao chép được nội dung, hãy bấm nút bên dưới để sao chép rồi dán vào khung chat."
                        : "Nội dung đăng ký đã được sao chép và cửa sổ Zalo với cô Ruby vừa mở ra. Làm theo các bước bên dưới để hoàn tất:"}
                    </p>

                    <ol className="mt-5 w-full max-w-sm space-y-3 text-left">
                      <li className="flex items-start gap-3 rounded-2xl bg-ruby-50/60 p-3">
                        <span className="grid h-7 w-7 shrink-0 place-items-center rounded-full bg-ruby-500 text-sm font-bold text-white">1</span>
                        <p className="text-sm text-ruby-950/80">
                          {isMobile
                            ? "Chuyển sang tab hoặc app Zalo vừa mở (nếu có cài app Zalo, máy sẽ tự mở app; nếu chưa, chọn \"Mở trong trình duyệt\" / Zalo Web)."
                            : "Chuyển sang tab Zalo Web vừa mở, đăng nhập nếu được yêu cầu."}
                        </p>
                      </li>
                      <li className="flex items-start gap-3 rounded-2xl bg-ruby-50/60 p-3">
                        <span className="grid h-7 w-7 shrink-0 place-items-center rounded-full bg-ruby-500 text-sm font-bold text-white">2</span>
                        <p className="text-sm text-ruby-950/80">
                          {isMobile
                            ? "Chạm và giữ vào khung nhập tin nhắn, chọn \"Dán\" (Paste) để nội dung đăng ký hiện ra."
                            : "Bấm vào khung nhập tin nhắn rồi nhấn Ctrl+V (hoặc Cmd+V trên Mac) để dán nội dung."}
                        </p>
                      </li>
                      <li className="flex items-start gap-3 rounded-2xl bg-ruby-50/60 p-3">
                        <span className="grid h-7 w-7 shrink-0 place-items-center rounded-full bg-ruby-500 text-sm font-bold text-white">3</span>
                        <p className="text-sm text-ruby-950/80">Nhấn nút gửi trong Zalo — vậy là cô Ruby sẽ nhận được thông tin của bạn ngay!</p>
                      </li>
                    </ol>

                    <div className="mt-5 flex flex-wrap items-center justify-center gap-3">
                      <button
                        type="button"
                        onClick={async () => {
                          const ok = await copyMessage(lastMessage);
                          setCopyOk(ok);
                          setCopiedAgain(ok);
                        }}
                        className="rounded-full bg-[#0068ff] px-5 py-2.5 text-sm font-bold text-white shadow-lg shadow-blue-900/20 transition-colors hover:bg-[#0057d8]"
                      >
                        {copiedAgain ? "Đã sao chép ✓" : "📋 Sao chép lại nội dung"}
                      </button>
                      <a
                        href={`https://zalo.me/${ZALO_PHONE}`}
                        target="_blank"
                        rel="noreferrer"
                        className="rounded-full bg-ruby-50 px-5 py-2.5 text-sm font-bold text-ruby-700 ring-1 ring-ruby-200 transition-colors hover:bg-ruby-100"
                      >
                        Mở lại Zalo
                      </a>
                    </div>

                    <button
                      onClick={() => setSent(false)}
                      className="mt-4 text-sm font-bold text-ruby-950/50 underline-offset-2 transition-colors hover:text-ruby-700 hover:underline"
                    >
                      Gửi đăng ký khác
                    </button>
                  </motion.div>
                ) : (
                  <motion.form
                    key="form"
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    exit={{ opacity: 0, scale: 0.95 }}
                    onSubmit={async (e) => {
                      e.preventDefault();
                      const form = e.currentTarget;
                      const data = new FormData(form);
                      const name = (data.get("name") as string || "").trim();
                      const phone = (data.get("phone") as string || "").trim();
                      const course = (data.get("course") as string || "").trim();
                      const message = (data.get("message") as string || "").trim();

                      const newErrors: Record<string, string> = {};
                      if (!name) newErrors.name = "Vui lòng nhập họ và tên.";
                      if (!phone) newErrors.phone = "Vui lòng nhập số điện thoại.";
                      else if (!/^[0-9+\s.-]{8,15}$/.test(phone)) newErrors.phone = "Số điện thoại không hợp lệ.";
                      if (!course) newErrors.course = "Vui lòng chọn khóa học quan tâm.";
                      if (!message) newErrors.message = "Vui lòng nhập lời nhắn.";

                      if (Object.keys(newErrors).length > 0) {
                        setErrors(newErrors);
                        return;
                      }
                      setErrors({});

                      const text =
                        `📩 ĐĂNG KÝ / TƯ VẤN HỌC — CO RUBY\n\n` +
                        `👤 Họ và tên: ${name}\n` +
                        `📞 Điện thoại: ${phone}\n` +
                        `📚 Khóa học quan tâm: ${course}\n` +
                        `💬 Lời nhắn: ${message}`;

                      setLastMessage(text);
                      setIsMobile(isMobileDevice());

                      // Copy first (must happen inside the click gesture, before await/open).
                      const ok = await copyMessage(text);
                      setCopyOk(ok);
                      setCopiedAgain(false);

                      // Open Zalo — on phones this jumps straight into the Zalo app (if installed).
                      window.open(`https://zalo.me/${ZALO_PHONE}`, "_blank", "noopener,noreferrer");

                      form.reset();
                      setSent(true);
                    }}
                    className="space-y-5"
                    noValidate
                  >
                    <h3 className="font-display text-2xl font-bold text-ruby-950">Đăng Ký / Tư Vấn Học</h3>
                    <div className="grid gap-5 sm:grid-cols-2">
                      <div>
                        <label className="mb-1.5 block text-xs font-bold tracking-widest text-ruby-950/60 uppercase">Họ và Tên</label>
                        <input
                          name="name"
                          type="text"
                          placeholder="Nguyễn Văn A"
                          className={`w-full rounded-xl border bg-ruby-50/40 px-4 py-3 text-sm text-ruby-950 outline-none transition-all duration-300 placeholder:text-ruby-950/35 focus:bg-white focus:ring-4 ${
                            errors.name
                              ? "border-red-400 focus:border-red-500 focus:ring-red-100"
                              : "border-ruby-200 focus:border-ruby-500 focus:ring-ruby-100"
                          }`}
                        />
                        {errors.name && <p className="mt-1 text-xs font-semibold text-red-500">{errors.name}</p>}
                      </div>
                      <div>
                        <label className="mb-1.5 block text-xs font-bold tracking-widest text-ruby-950/60 uppercase">Điện Thoại</label>
                        <input
                          name="phone"
                          type="tel"
                          placeholder="03xx xxx xxx"
                          className={`w-full rounded-xl border bg-ruby-50/40 px-4 py-3 text-sm text-ruby-950 outline-none transition-all duration-300 placeholder:text-ruby-950/35 focus:bg-white focus:ring-4 ${
                            errors.phone
                              ? "border-red-400 focus:border-red-500 focus:ring-red-100"
                              : "border-ruby-200 focus:border-ruby-500 focus:ring-ruby-100"
                          }`}
                        />
                        {errors.phone && <p className="mt-1 text-xs font-semibold text-red-500">{errors.phone}</p>}
                      </div>
                    </div>
                    <div>
                      <label className="mb-1.5 block text-xs font-bold tracking-widest text-ruby-950/60 uppercase">Khóa Học Quan Tâm</label>
                      <select
                        name="course"
                        className={`w-full rounded-xl border bg-ruby-50/40 px-4 py-3 text-sm text-ruby-950 outline-none transition-all duration-300 focus:bg-white focus:ring-4 ${
                          errors.course
                            ? "border-red-400 focus:border-red-500 focus:ring-red-100"
                            : "border-ruby-200 focus:border-ruby-500 focus:ring-ruby-100"
                        }`}
                        defaultValue=""
                      >
                        <option value="" disabled>— Chọn khóa học —</option>
                        <option>Tiếng Anh Giao Tiếp</option>
                        <option>Tiếng Anh Học Thuật</option>
                        <option>Ôn Thi (THPT / IELTS / TOEIC / Vstep)</option>
                        <option>Tiếng Trung</option>
                        <option>Chương Trình Đặc Biệt</option>
                        <option>Tin Học</option>
                      </select>
                      {errors.course && <p className="mt-1 text-xs font-semibold text-red-500">{errors.course}</p>}
                    </div>
                    <div>
                      <label className="mb-1.5 block text-xs font-bold tracking-widest text-ruby-950/60 uppercase">Lời Nhắn</label>
                      <textarea
                        name="message"
                        rows={4}
                        placeholder="Ví dụ: Con năm nay 10 tuổi, muốn học tiếng Anh giao tiếp vào buổi tối..."
                        className={`w-full resize-none rounded-xl border bg-ruby-50/40 px-4 py-3 text-sm text-ruby-950 outline-none transition-all duration-300 placeholder:text-ruby-950/35 focus:bg-white focus:ring-4 ${
                          errors.message
                            ? "border-red-400 focus:border-red-500 focus:ring-red-100"
                            : "border-ruby-200 focus:border-ruby-500 focus:ring-ruby-100"
                        }`}
                      />
                      {errors.message && <p className="mt-1 text-xs font-semibold text-red-500">{errors.message}</p>}
                    </div>
                    <motion.button
                      type="submit"
                      whileHover={{ scale: 1.02 }}
                      whileTap={{ scale: 0.97 }}
                      className="group relative w-full overflow-hidden rounded-xl bg-gradient-to-r from-ruby-600 to-ruby-500 px-6 py-4 text-base font-bold text-white shadow-xl shadow-ruby-600/25"
                    >
                      <span className="relative z-10">Gửi Đăng Ký ✦</span>
                      <span className="absolute inset-0 -translate-x-full bg-gradient-to-r from-transparent via-white/25 to-transparent transition-transform duration-700 group-hover:translate-x-full" />
                    </motion.button>
                    <p className="text-center text-xs text-ruby-950/50">
                      Sau khi bấm gửi, nội dung sẽ được sao chép và Zalo với cô Ruby sẽ tự mở ra (trên điện thoại lẫn máy tính) — bạn chỉ cần dán và nhấn gửi.
                    </p>
                  </motion.form>
                )}
              </AnimatePresence>
            </div>
          </Reveal>
        </div>
      </div>
    </section>
  );
}
