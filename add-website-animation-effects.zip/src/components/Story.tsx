import { motion } from "framer-motion";
import { Reveal, SectionHead, TiltCard } from "./shared";

const timeline = [
  {
    n: "01",
    title: "Khởi Đầu Từ Niềm Đam Mê",
    desc: "Thành lập ngày 19/12/2024 bởi Cô Phạm Thị Ngọc Diễm (Mrs. Ruby), xuất phát từ niềm tin rằng ngôn ngữ là chìa khóa mở ra cơ hội không giới hạn.",
    icon: "🌱",
  },
  {
    n: "02",
    title: "Từ Những Buổi Học Đầu Tiên",
    desc: "Bắt đầu với mô hình nhỏ tại nhà, nơi mỗi học sinh được nhớ tên, hiểu điểm mạnh và điểm cần cải thiện riêng biệt.",
    icon: "📖",
  },
  {
    n: "03",
    title: "Triết Lý Giáo Dục Song Ngữ",
    desc: "Kết hợp ngữ pháp chuyên sâu, giao tiếp thực tế và luyện thi có định hướng. Hiện có 2 phòng học riêng biệt với sức chứa khoảng 40 học sinh mỗi buổi.",
    icon: "🌏",
  },
  {
    n: "04",
    title: 'Tên "Ruby" — Ý Nghĩa Đặc Biệt',
    desc: "Ruby — viên đá quý màu đỏ — tượng trưng cho sự quý giá, bền vững và ánh sáng. Mỗi học viên được mài giũa để tỏa sáng.",
    icon: "💎",
  },
];

const values = [
  { n: "01", title: "Tận Tâm", en: "Dedication", icon: "🎯", desc: "Chúng tôi không dạy theo số lượng — chúng tôi dạy theo chất lượng từng buổi học, từng học viên." },
  { n: "02", title: "Cá Nhân Hóa", en: "Personalization", icon: "📚", desc: "Lộ trình học được thiết kế riêng dựa trên điểm xuất phát, mục tiêu và nhịp độ tiếp thu của từng người." },
  { n: "03", title: "Thực Dụng", en: "Practicality", icon: "🛠️", desc: "Kiến thức phải ứng dụng được trong cuộc sống thực. Từ giao tiếp hàng ngày đến phòng thi." },
  { n: "04", title: "Đồng Hành", en: "Companionship", icon: "🤝", desc: "Chúng tôi không chỉ là giáo viên — chúng tôi là người bạn đồng hành, động viên trong mỗi bước tiến." },
  { n: "05", title: "Liêm Chính", en: "Integrity", icon: "⚖️", desc: "Cam kết minh bạch về lộ trình, tiến độ và kết quả. Chỉ cam kết thực sự và đo lường được." },
];

export default function Story() {
  return (
    <>
      {/* ===== STORY / TIMELINE ===== */}
      <section id="story" className="relative bg-white py-24">
        <div className="pointer-events-none absolute top-0 left-1/2 h-64 w-[700px] -translate-x-1/2 rounded-full bg-ruby-50 blur-3xl" />
        <div className="relative mx-auto max-w-7xl px-5 lg:px-8">
          <SectionHead
            kicker="Hành Trình Của Chúng Tôi"
            title="Lịch Sử Hình Thành"
            sub="Mỗi viên ruby đều bắt đầu từ một tinh thể thô — hành trình của CO RUBY cũng vậy."
          />

          <div className="relative">
            {/* vertical line */}
            <motion.div
              initial={{ scaleY: 0 }}
              whileInView={{ scaleY: 1 }}
              viewport={{ once: true, margin: "-100px" }}
              transition={{ duration: 1.4, ease: "easeInOut" }}
              className="absolute top-0 bottom-0 left-5 w-0.5 origin-top bg-gradient-to-b from-ruby-400 via-ruby-600 to-ruby-200 md:left-1/2 md:-translate-x-1/2"
            />

            <div className="space-y-12">
              {timeline.map((t, i) => {
                const left = i % 2 === 0;
                return (
                  <div key={t.n} className={`relative flex md:items-center ${left ? "md:flex-row" : "md:flex-row-reverse"}`}>
                    {/* dot */}
                    <motion.span
                      initial={{ scale: 0 }}
                      whileInView={{ scale: 1 }}
                      viewport={{ once: true }}
                      transition={{ type: "spring", stiffness: 200, delay: 0.2 }}
                      className="absolute left-5 z-10 grid h-10 w-10 -translate-x-1/2 place-items-center rounded-full bg-gradient-to-br from-ruby-500 to-ruby-700 text-sm shadow-lg shadow-ruby-500/40 md:left-1/2"
                    >
                      {t.icon}
                    </motion.span>

                    <div className={`ml-14 w-full md:ml-0 md:w-1/2 ${left ? "md:pr-14" : "md:pl-14"}`}>
                      <Reveal delay={left ? 0.1 : 0} y={left ? 30 : 30} className={left ? "" : ""}>
                        <motion.div
                          whileHover={{ y: -8 }}
                          transition={{ type: "spring", stiffness: 300 }}
                          className="group relative overflow-hidden rounded-3xl border border-ruby-100 bg-gradient-to-br from-white to-ruby-50/60 p-7 shadow-lg shadow-ruby-900/5 transition-shadow duration-500 hover:shadow-2xl hover:shadow-ruby-500/15"
                        >
                          <span className="pointer-events-none absolute -top-4 -right-2 font-display text-7xl font-extrabold text-ruby-100 transition-colors duration-500 group-hover:text-ruby-200">
                            {t.n}
                          </span>
                          <h3 className="relative font-display text-xl font-bold text-ruby-950">{t.title}</h3>
                          <p className="relative mt-3 text-sm leading-relaxed text-ruby-950/65">{t.desc}</p>
                        </motion.div>
                      </Reveal>
                    </div>
                    <div className="hidden md:block md:w-1/2" />
                  </div>
                );
              })}
            </div>
          </div>

          {/* Quote */}
          <Reveal delay={0.1}>
            <div className="relative mt-20 overflow-hidden rounded-[2.5rem] bg-gradient-to-br from-ruby-600 via-ruby-500 to-rose-400 px-8 py-14 text-center shadow-2xl shadow-ruby-500/30 sm:px-16">
              <span className="pointer-events-none absolute -top-10 left-10 font-display text-[12rem] leading-none text-white/10 select-none">“</span>
              <p className="relative mx-auto max-w-3xl font-display text-2xl leading-snug font-semibold text-white italic sm:text-3xl">
                “Chúng tôi không chỉ dạy ngôn ngữ — chúng tôi truyền cảm hứng để học viên tin vào chính mình.”
              </p>
              <p className="relative mt-6 text-sm font-bold tracking-[0.2em] text-white/90 uppercase">
                — Phạm Thị Ngọc Diễm (Mrs. Ruby), Người Sáng Lập
              </p>
              <p className="relative mt-8 inline-block rounded-full bg-white/20 px-5 py-2 text-sm text-white ring-1 ring-white/30">
                📍 Phục vụ học sinh từ 4 tuổi trở lên tại khu vực Chi Lăng, Tịnh Biên, An Giang và các vùng lân cận
              </p>
            </div>
          </Reveal>
        </div>
      </section>

      {/* ===== CORE VALUES ===== */}
      <section className="relative bg-gradient-to-b from-ruby-50/70 to-white py-24">
        <div className="mx-auto max-w-7xl px-5 lg:px-8">
          <SectionHead
            kicker="Giá Trị Cốt Lõi"
            title="Những Điều Chúng Tôi Tin"
            sub="Mỗi quyết định, mỗi buổi học đều được xây dựng trên nền tảng 5 giá trị cốt lõi này."
          />

          <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
            {values.map((v, i) => (
              <Reveal key={v.n} delay={i * 0.08}>
                <TiltCard className="group relative h-full overflow-hidden rounded-3xl border border-ruby-100 bg-white p-7 shadow-lg shadow-ruby-900/5 hover:shadow-2xl hover:shadow-ruby-500/15">
                  <div className="absolute -top-12 -right-12 h-32 w-32 rounded-full bg-ruby-50 transition-transform duration-700 group-hover:scale-[2.2]" />
                  <div className="relative">
                    <span className="grid h-14 w-14 place-items-center rounded-2xl bg-gradient-to-br from-ruby-500 to-ruby-700 text-2xl shadow-lg shadow-ruby-500/30 transition-transform duration-500 group-hover:rotate-12 group-hover:scale-110">
                      {v.icon}
                    </span>
                    <div className="mt-5 flex items-baseline gap-3">
                      <h3 className="font-display text-xl font-bold text-ruby-950">{v.title}</h3>
                      <span className="text-xs font-semibold tracking-widest text-ruby-400 uppercase">{v.en}</span>
                    </div>
                    <p className="mt-3 text-sm leading-relaxed text-ruby-950/65">{v.desc}</p>
                    <span className="mt-5 block font-display text-4xl font-extrabold text-ruby-100 transition-colors duration-500 group-hover:text-ruby-300">
                      {v.n}
                    </span>
                  </div>
                </TiltCard>
              </Reveal>
            ))}

            {/* decorative 6th card */}
            <Reveal delay={0.4}>
              <div className="relative flex h-full flex-col items-center justify-center overflow-hidden rounded-3xl bg-gradient-to-br from-ruby-600 to-ruby-800 p-7 text-center shadow-xl shadow-ruby-700/30">
                <motion.span
                  animate={{ rotate: 360 }}
                  transition={{ duration: 20, repeat: Infinity, ease: "linear" }}
                  className="text-6xl"
                >
                  💎
                </motion.span>
                <p className="mt-4 font-display text-2xl font-bold text-white">Mài Giũa Để Tỏa Sáng</p>
                <p className="mt-2 text-sm text-ruby-100/80">Mỗi học viên là một viên ruby đang chờ được đánh bóng.</p>
              </div>
            </Reveal>
          </div>
        </div>
      </section>
    </>
  );
}
