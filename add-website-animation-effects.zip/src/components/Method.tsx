import { motion } from "framer-motion";
import { Reveal, SectionHead } from "./shared";

const steps = [
  { n: "01", icon: "🔍", title: "Chẩn Đoán Đầu Vào", desc: "Đánh giá trình độ, xác định điểm mạnh/yếu và thiết lập lộ trình học cá nhân hóa." },
  { n: "02", icon: "🎯", title: "Dạy Cá Nhân Hóa", desc: "Bài giảng thiết kế riêng, tốc độ phù hợp từng học viên, phản hồi tức thì sau mỗi buổi." },
  { n: "03", icon: "📈", title: "Theo Dõi & Điều Chỉnh", desc: "Kiểm tra định kỳ, báo cáo tiến độ cho phụ huynh, điều chỉnh phương pháp liên tục." },
];

const formats = [
  { icon: "1️⃣", title: "1 Kèm 1", en: "One-on-One", desc: "Tập trung tuyệt đối · Tiến độ nhanh nhất" },
  { icon: "2️⃣", title: "1 Kèm 2", en: "One-on-Two", desc: "Học cùng bạn · Tiết kiệm học phí" },
  { icon: "🍵", title: "Lớp Đại Trà", en: "Group Class", desc: "Tự học có hướng dẫn · Ngữ pháp & từ vựng" },
  { icon: "⏰", title: "Linh Hoạt", en: "Flexible", desc: "Điều chỉnh lịch học · Theo nhu cầu" },
];

export default function Method() {
  return (
    <section id="method" className="relative overflow-hidden bg-gradient-to-br from-ruby-100 via-rose-50 to-rose-100 py-24">
      <div className="pointer-events-none absolute -top-32 right-0 h-96 w-96 rounded-full bg-ruby-300/50 blur-[100px]" />
      <div className="pointer-events-none absolute bottom-0 -left-32 h-96 w-96 rounded-full bg-rose-300/50 blur-[100px]" />

      <div className="relative mx-auto max-w-7xl px-5 lg:px-8">
        <SectionHead
          kicker="Mô Hình Dạy Học"
          title="Phương Pháp Giảng Dạy"
          sub="Ba bước quy trình khoa học giúp mỗi học viên tiến bộ nhanh nhất theo cách riêng của mình."
        />

        {/* 3 steps */}
        <div className="relative grid gap-8 md:grid-cols-3">
          {/* connecting line */}
          <motion.div
            initial={{ scaleX: 0 }}
            whileInView={{ scaleX: 1 }}
            viewport={{ once: true }}
            transition={{ duration: 1.2, ease: "easeInOut" }}
            className="absolute top-16 right-[16%] left-[16%] hidden h-0.5 origin-left bg-gradient-to-r from-ruby-400/70 via-rose-400/70 to-ruby-400/70 md:block"
          />
          {steps.map((s, i) => (
            <Reveal key={s.n} delay={i * 0.15}>
              <div className="group relative text-center">
                <motion.span
                  whileHover={{ scale: 1.1, rotate: 8 }}
                  transition={{ type: "spring", stiffness: 300 }}
                  className="relative z-10 mx-auto grid h-32 w-32 place-items-center rounded-full bg-gradient-to-br from-white to-ruby-50 shadow-xl shadow-ruby-500/15 ring-1 ring-ruby-100"
                >
                  <span className="absolute inset-0 rounded-full bg-ruby-400/30 animate-pulse-ring" style={{ animationDelay: `${i * 0.5}s` }} />
                  <span className="text-5xl">{s.icon}</span>
                  <span className="absolute -top-1 -right-1 grid h-9 w-9 place-items-center rounded-full bg-gradient-to-br from-ruby-500 to-ruby-600 font-display text-sm font-extrabold text-white shadow-lg">
                    {s.n}
                  </span>
                </motion.span>
                <h3 className="mt-6 font-display text-xl font-bold text-ruby-950">{s.title}</h3>
                <p className="mx-auto mt-3 max-w-xs text-sm leading-relaxed text-ruby-950/60">{s.desc}</p>
              </div>
            </Reveal>
          ))}
        </div>

        {/* Formats */}
        <Reveal delay={0.1}>
          <h3 className="mt-24 text-center font-display text-2xl font-bold text-ruby-950 sm:text-3xl">
            Hình Thức Học Tập
          </h3>
        </Reveal>
        <div className="mt-10 grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
          {formats.map((f, i) => (
            <Reveal key={f.title} delay={i * 0.1}>
              <motion.div
                whileHover={{ y: -10 }}
                transition={{ type: "spring", stiffness: 300 }}
                className="group relative overflow-hidden rounded-3xl bg-white/80 p-6 ring-1 ring-ruby-100 backdrop-blur transition-colors duration-500 hover:bg-white hover:ring-ruby-300"
              >
                <motion.span
                  animate={{ y: [0, -8, 0] }}
                  transition={{ duration: 3.5, repeat: Infinity, delay: i * 0.4, ease: "easeInOut" }}
                  className="inline-block text-4xl"
                >
                  {f.icon}
                </motion.span>
                <h4 className="mt-4 font-display text-lg font-bold text-ruby-950">{f.title}</h4>
                <p className="text-xs font-semibold tracking-widest text-ruby-500 uppercase">{f.en}</p>
                <p className="mt-2.5 text-sm text-ruby-950/60">{f.desc}</p>
              </motion.div>
            </Reveal>
          ))}
        </div>

        <Reveal delay={0.2}>
          <p className="mt-12 text-center text-sm font-semibold text-ruby-700">
            ✦ Lớp học linh hoạt phù hợp học sinh từ 4 tuổi trở lên — Phụ huynh đăng ký theo lịch phù hợp
          </p>
        </Reveal>
      </div>
    </section>
  );
}
