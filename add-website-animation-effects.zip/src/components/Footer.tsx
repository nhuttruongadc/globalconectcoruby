export default function Footer() {
  return (
    <footer className="relative border-t border-white/10 bg-ruby-900 py-12">
      <div className="mx-auto max-w-7xl px-5 lg:px-8">
        <div className="flex flex-col items-center gap-8 md:flex-row md:justify-between">
          <div className="flex items-center gap-3">
            <span className="grid h-11 w-11 place-items-center rounded-xl bg-white p-1.5 shadow-lg shadow-ruby-950/30">
              <img src="/images/logo-icon.png" alt="Ruby Class logo" className="h-full w-full object-contain" />
            </span>
            <div className="leading-tight">
              <p className="font-display text-lg font-extrabold tracking-wide text-white">CO RUBY</p>
              <p className="text-[10px] font-semibold tracking-[0.25em] text-ruby-300 uppercase">A Global Connect</p>
            </div>
          </div>

          <nav className="flex flex-wrap justify-center gap-x-6 gap-y-2">
            {[
              ["Về Chúng Tôi", "#story"],
              ["Khóa Học", "#courses"],
              ["Phương Pháp", "#method"],
              ["Thành Tích", "#achievements"],
              ["Giảng Viên", "#founder"],
              ["Liên Hệ", "#contact"],
            ].map(([label, href]) => (
              <a
                key={href}
                href={href}
                className="text-sm font-semibold text-ruby-200/70 transition-colors duration-300 hover:text-white"
              >
                {label}
              </a>
            ))}
          </nav>

          <a
            href="tel:0344878674"
            className="rounded-full bg-white/10 px-5 py-2.5 text-sm font-bold text-white ring-1 ring-white/20 transition-all duration-300 hover:bg-white/20"
          >
            📞 0344 878 674
          </a>
        </div>

        <div className="mt-10 border-t border-white/10 pt-6 text-center">
          <p className="text-xs text-ruby-200/50">
            © {new Date().getFullYear()} CO RUBY — A Global Connect · Tiếng Anh · Tiếng Trung · Tin Học
          </p>
          <p className="mt-1 text-xs text-ruby-200/40">
            “Ngôn ngữ là sức mạnh — Chúng tôi trao nó cho bạn.” ✦
          </p>
        </div>
      </div>
    </footer>
  );
}
