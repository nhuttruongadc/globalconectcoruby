import { motion } from "framer-motion";
import { Reveal, SectionHead, TiltCard } from "./shared";

const prizes = [
  {
    icon: "🏆",
    title: "Giải Nhất – Hùng Biện Cấp Trường",
    student: "Học sinh Như Mộng – THPT Chi Lăng",
    en: "1st Prize – School Debate Competition · Grade 10",
  },
  {
    icon: "🥇",
    title: "Giải Nhất – Violympic Tiếng Anh",
    student: "Học sinh Phúc Hưng – Tiểu Học A Chi Lăng",
    en: "1st Prize – English Violympic Competition · Grade 1",
  },
];

const reviews = [
  "Con tôi tự tin hơn, nắm vững căn bản và biết giải thích vấn đề sau 3 tháng học tại Trung tâm Ruby.",
  "Các em được hướng dẫn tận tình, tham gia nhiều hoạt động tương tác thú vị, học mà như chơi.",
  "Cô giáo rất tận tâm, từng bước một sửa phát âm cho bé. Con thích đi học lắm rồi!",
];

export default function Achievements() {
  return (
    <section id="achievements" className="relative bg-white py-24">
      <div className="pointer-events-none absolute top-32 -left-32 h-96 w-96 rounded-full bg-amber-50 blur-3xl" />
      <div className="relative mx-auto max-w-7xl px-5 lg:px-8">
        <SectionHead
          kicker="Thành Tích & Bằng Khen"
          title="Kết Quả Nổi Bật"
          sub="Những thành quả tự hào của học viên và giảng viên — minh chứng cho chất lượng giảng dạy."
        />

        {/* Prize cards */}
        <div className="grid gap-6 md:grid-cols-2">
          {prizes.map((p, i) => (
            <Reveal key={p.title} delay={i * 0.12}>
              <TiltCard className="group relative h-full overflow-hidden rounded-3xl border-2 border-amber-200/70 bg-gradient-to-br from-amber-50 via-white to-rose-50 p-8 shadow-xl shadow-amber-900/5">
                <div className="absolute -top-10 -right-10 h-40 w-40 rounded-full bg-amber-100/60 transition-transform duration-700 group-hover:scale-150" />
                <motion.span
                  animate={{ rotate: [0, -12, 12, 0] }}
                  transition={{ duration: 3, repeat: Infinity, delay: i * 0.8, ease: "easeInOut" }}
                  className="relative inline-block text-6xl drop-shadow-lg"
                >
                  {p.icon}
                </motion.span>
                <h3 className="relative mt-5 font-display text-2xl font-bold text-ruby-950">{p.title}</h3>
                <p className="relative mt-2 text-sm font-semibold text-ruby-700">{p.student}</p>
                <p className="relative mt-1 text-xs tracking-wide text-ruby-950/50 italic">{p.en}</p>
                <div className="relative mt-5 flex gap-1">
                  {[...Array(5)].map((_, s) => (
                    <motion.span
                      key={s}
                      initial={{ opacity: 0, scale: 0 }}
                      whileInView={{ opacity: 1, scale: 1 }}
                      viewport={{ once: true }}
                      transition={{ delay: 0.4 + s * 0.12, type: "spring" }}
                      className="text-xl"
                    >
                      ⭐
                    </motion.span>
                  ))}
                </div>
              </TiltCard>
            </Reveal>
          ))}
        </div>

        {/* Reviews marquee */}
        <Reveal delay={0.15}>
          <div className="relative mt-14 overflow-hidden rounded-3xl bg-gradient-to-r from-ruby-50 to-rose-50 py-8 ring-1 ring-ruby-100">
            <div className="pointer-events-none absolute inset-y-0 left-0 z-10 w-24 bg-gradient-to-r from-ruby-50 to-transparent" />
            <div className="pointer-events-none absolute inset-y-0 right-0 z-10 w-24 bg-gradient-to-l from-rose-50 to-transparent" />
            <div className="flex w-max animate-marquee gap-6">
              {[...reviews, ...reviews, ...reviews].map((r, i) => (
                <div key={i} className="w-[320px] shrink-0 rounded-2xl bg-white p-5 shadow-md shadow-ruby-900/5 sm:w-[420px]">
                  <div className="flex gap-1 text-amber-400">{"★★★★★"}</div>
                  <p className="mt-3 text-sm leading-relaxed text-ruby-950/75 italic">“{r}”</p>
                  <p className="mt-3 text-xs font-bold text-ruby-600">— Phụ huynh học viên CO RUBY</p>
                </div>
              ))}
            </div>
          </div>
        </Reveal>
      </div>
    </section>
  );
}
