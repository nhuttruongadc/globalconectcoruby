import { motion, useInView } from "framer-motion";
import { useEffect, useRef, useState, type ReactNode } from "react";

/* ---------- Reveal on scroll ---------- */
export function Reveal({
  children,
  delay = 0,
  y = 40,
  className = "",
}: {
  children: ReactNode;
  delay?: number;
  y?: number;
  className?: string;
}) {
  return (
    <motion.div
      className={className}
      initial={{ opacity: 0, y }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: "-60px" }}
      transition={{ duration: 0.7, delay, ease: [0.22, 1, 0.36, 1] }}
    >
      {children}
    </motion.div>
  );
}

/* ---------- Section heading ---------- */
export function SectionHead({
  kicker,
  title,
  sub,
  light = false,
}: {
  kicker: string;
  title: string;
  sub?: string;
  light?: boolean;
}) {
  return (
    <div className="mx-auto mb-14 max-w-2xl text-center">
      <Reveal>
        <span
          className={`inline-flex items-center gap-2 rounded-full px-4 py-1.5 text-xs font-bold tracking-widest uppercase ${
            light
              ? "bg-white/10 text-ruby-200 ring-1 ring-white/20"
              : "bg-ruby-50 text-ruby-700 ring-1 ring-ruby-200"
          }`}
        >
          <span className="text-sm">✦</span> {kicker}
        </span>
      </Reveal>
      <Reveal delay={0.1}>
        <h2
          className={`mt-5 font-display text-3xl font-bold tracking-tight sm:text-4xl md:text-[2.6rem] ${
            light ? "text-white" : "text-ruby-950"
          }`}
        >
          {title}
        </h2>
      </Reveal>
      {sub && (
        <Reveal delay={0.2}>
          <p className={`mt-4 text-base leading-relaxed ${light ? "text-ruby-100/70" : "text-ruby-950/60"}`}>
            {sub}
          </p>
        </Reveal>
      )}
    </div>
  );
}

/* ---------- Animated counter ---------- */
export function Counter({ to, suffix = "" }: { to: number; suffix?: string }) {
  const ref = useRef<HTMLSpanElement>(null);
  const inView = useInView(ref, { once: true, margin: "-40px" });
  const [val, setVal] = useState(0);

  useEffect(() => {
    if (!inView) return;
    const dur = 1400;
    const t0 = performance.now();
    let raf = 0;
    const tick = (t: number) => {
      const p = Math.min(1, (t - t0) / dur);
      const eased = 1 - Math.pow(1 - p, 3);
      setVal(Math.round(to * eased));
      if (p < 1) raf = requestAnimationFrame(tick);
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, [inView, to]);

  return (
    <span ref={ref}>
      {val}
      {suffix}
    </span>
  );
}

/* ---------- Floating sparkles background ---------- */
export function Sparkles({ count = 14, className = "" }: { count?: number; className?: string }) {
  const items = Array.from({ length: count }, (_, i) => i);
  return (
    <div className={`pointer-events-none absolute inset-0 overflow-hidden ${className}`} aria-hidden>
      {items.map((i) => (
        <motion.span
          key={i}
          className="absolute text-ruby-300"
          style={{
            left: `${(i * 37 + 13) % 100}%`,
            top: `${(i * 53 + 7) % 100}%`,
            fontSize: `${10 + ((i * 7) % 16)}px`,
          }}
          animate={{ y: [0, -18, 0], opacity: [0.2, 0.9, 0.2], rotate: [0, 30, 0] }}
          transition={{ duration: 4 + (i % 5), repeat: Infinity, delay: i * 0.4, ease: "easeInOut" }}
        >
          ✦
        </motion.span>
      ))}
    </div>
  );
}

/* ---------- Tilt card (mouse follow) ---------- */
export function TiltCard({
  children,
  className = "",
  max = 8,
}: {
  children: ReactNode;
  className?: string;
  max?: number;
}) {
  const ref = useRef<HTMLDivElement>(null);
  const [style, setStyle] = useState<React.CSSProperties>({});

  const onMove = (e: React.MouseEvent) => {
    const el = ref.current;
    if (!el) return;
    const r = el.getBoundingClientRect();
    const px = (e.clientX - r.left) / r.width - 0.5;
    const py = (e.clientY - r.top) / r.height - 0.5;
    setStyle({
      transform: `perspective(900px) rotateY(${px * max}deg) rotateX(${-py * max}deg) translateY(-6px)`,
    });
  };

  return (
    <div
      ref={ref}
      onMouseMove={onMove}
      onMouseLeave={() => setStyle({ transform: "perspective(900px) rotateY(0) rotateX(0)" })}
      style={style}
      className={`card-3d ${className}`}
    >
      {children}
    </div>
  );
}
