import { useEffect, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";

const links = [
  { label: "Về Chúng Tôi", href: "#story" },
  { label: "Khóa Học", href: "#courses" },
  { label: "Phương Pháp", href: "#method" },
  { label: "Thành Tích", href: "#achievements" },
  { label: "Giảng Viên", href: "#founder" },
  { label: "Liên Hệ", href: "#contact" },
];

export default function Header() {
  const [scrolled, setScrolled] = useState(false);
  const [open, setOpen] = useState(false);

  useEffect(() => {
    const fn = () => setScrolled(window.scrollY > 24);
    window.addEventListener("scroll", fn, { passive: true });
    return () => window.removeEventListener("scroll", fn);
  }, []);

  return (
    <motion.header
      initial={{ y: -80, opacity: 0 }}
      animate={{ y: 0, opacity: 1 }}
      transition={{ duration: 0.7, ease: [0.22, 1, 0.36, 1] }}
      className={`fixed inset-x-0 top-0 z-50 transition-all duration-500 ${
        scrolled
          ? "bg-white/85 shadow-lg shadow-ruby-900/5 backdrop-blur-xl"
          : "bg-transparent"
      }`}
    >
      <div className="mx-auto flex max-w-7xl items-center justify-between px-5 py-3.5 lg:px-8">
        <a href="#top" className="group flex items-center gap-2.5">
          <span className="relative grid h-11 w-11 place-items-center rounded-xl bg-gradient-to-br from-ruby-100 to-white p-1.5 shadow-lg shadow-ruby-500/20 transition-transform duration-500 group-hover:rotate-12">
            <img src="/images/logo-icon.png" alt="Ruby Class logo" className="h-full w-full object-contain" />
            <span className="absolute inset-0 rounded-xl bg-ruby-400/30 animate-pulse-ring" />
          </span>
          <span className="leading-tight">
            <span className="block font-display text-lg font-extrabold tracking-wide text-ruby-950">
              CO RUBY
            </span>
            <span className="block text-[10px] font-semibold tracking-[0.25em] uppercase text-ruby-500">
              A Global Connect
            </span>
          </span>
        </a>

        <nav className="hidden items-center gap-1 lg:flex">
          {links.map((l) => (
            <a
              key={l.href}
              href={l.href}
              className="relative rounded-full px-4 py-2 text-sm font-semibold text-ruby-950/75 transition-colors duration-300 after:absolute after:bottom-1 after:left-1/2 after:h-0.5 after:w-0 after:-translate-x-1/2 after:rounded-full after:bg-ruby-500 after:transition-all after:duration-300 hover:text-ruby-600 hover:after:w-6"
            >
              {l.label}
            </a>
          ))}
        </nav>

        <div className="flex items-center gap-3">
          <a
            href="tel:0344878674"
            className="hidden items-center gap-2 rounded-full bg-gradient-to-r from-ruby-600 to-ruby-500 px-5 py-2.5 text-sm font-bold text-white shadow-lg shadow-ruby-600/30 transition-all duration-300 hover:scale-105 hover:shadow-xl hover:shadow-ruby-600/40 sm:flex"
          >
            <span className="relative flex h-2 w-2">
              <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-white opacity-70" />
              <span className="relative inline-flex h-2 w-2 rounded-full bg-white" />
            </span>
            0344 878 674
          </a>

          <button
            onClick={() => setOpen(!open)}
            aria-label="Menu"
            className={`grid h-10 w-10 place-items-center rounded-xl transition-colors lg:hidden ${
              scrolled ? "bg-ruby-100/80 text-ruby-800" : "bg-white/70 text-ruby-800 backdrop-blur"
            }`}
          >
            <div className="space-y-1.5">
              <span className={`block h-0.5 w-5 rounded bg-current transition-transform duration-300 ${open ? "translate-y-2 rotate-45" : ""}`} />
              <span className={`block h-0.5 w-5 rounded bg-current transition-opacity duration-300 ${open ? "opacity-0" : ""}`} />
              <span className={`block h-0.5 w-5 rounded bg-current transition-transform duration-300 ${open ? "-translate-y-2 -rotate-45" : ""}`} />
            </div>
          </button>
        </div>
      </div>

      <AnimatePresence>
        {open && (
          <motion.nav
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: "auto", opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            transition={{ duration: 0.35, ease: [0.22, 1, 0.36, 1] }}
            className="overflow-hidden bg-white/95 backdrop-blur-xl lg:hidden"
          >
            <div className="space-y-1 px-5 pb-5">
              {links.map((l, i) => (
                <motion.a
                  key={l.href}
                  href={l.href}
                  onClick={() => setOpen(false)}
                  initial={{ x: -20, opacity: 0 }}
                  animate={{ x: 0, opacity: 1 }}
                  transition={{ delay: i * 0.05 }}
                  className="block rounded-xl px-4 py-3 text-sm font-semibold text-ruby-950 transition-colors hover:bg-ruby-50 hover:text-ruby-700"
                >
                  {l.label}
                </motion.a>
              ))}
              <a
                href="tel:0344878674"
                className="mt-2 flex items-center justify-center gap-2 rounded-xl bg-gradient-to-r from-ruby-600 to-ruby-500 px-4 py-3 text-sm font-bold text-white"
              >
                📞 0344 878 674
              </a>
            </div>
          </motion.nav>
        )}
      </AnimatePresence>
    </motion.header>
  );
}
