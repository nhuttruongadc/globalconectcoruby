import { Reveal, SectionHead, TiltCard } from "./shared";

const items = [
  { icon: "📺", title: "Màn Hình TV 55–75 Inch", en: 'TV Screen 55–75"', desc: "Bài giảng trực quan và trình chiếu sinh động cho toàn lớp." },
  { icon: "❄️", title: "Máy Lạnh 2 HP", en: "2 HP Air Conditioning", desc: "Mỗi phòng học đều có máy lạnh, đảm bảo thoải mái dù thời tiết nóng bức." },
  { icon: "🖨️", title: "Máy In & Scan Wi-Fi", en: "Wi-Fi Printer & Scanner", desc: "In ấn và lưu trữ bài tập, tài liệu học tập nhanh chóng, tiện lợi." },
  { icon: "💻", title: "Dàn PC & Laptop", en: "PC & Laptop Stations", desc: "Hỗ trợ học tin học và tiếng Anh — học sinh luyện tập trực tiếp trên máy." },
  { icon: "📚", title: "Thư Viện Sách Miễn Phí", en: "Free Library", desc: "Tài liệu tham khảo đa dạng, phong phú cho tất cả học sinh, hoàn toàn miễn phí." },
  { icon: "🍽️", title: "Canteen Phục Vụ", en: "Canteen", desc: "Đồ ăn và nước uống cơ bản để đảm bảo sức khỏe và năng lượng cho buổi học." },
];

export default function Facilities() {
  return (
    <section className="relative bg-white py-24">
      <div className="mx-auto max-w-7xl px-5 lg:px-8">
        <SectionHead
          kicker="Tiện Ích Lớp Học"
          title="Cơ Sở Vật Chất"
          sub="Trang bị đầy đủ tiện nghi để học sinh học tập hiệu quả trong môi trường hiện đại."
        />

        <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {items.map((f, i) => (
            <Reveal key={f.title} delay={i * 0.08}>
              <TiltCard max={6} className="group h-full rounded-3xl border border-ruby-100 bg-gradient-to-br from-white to-ruby-50/40 p-7 shadow-lg shadow-ruby-900/5 hover:shadow-2xl hover:shadow-ruby-500/15">
                <span className="inline-grid h-16 w-16 place-items-center rounded-2xl bg-white text-3xl shadow-md shadow-ruby-900/10 ring-1 ring-ruby-100 transition-all duration-500 group-hover:-rotate-6 group-hover:scale-110 group-hover:bg-gradient-to-br group-hover:from-ruby-500 group-hover:to-ruby-700">
                  {f.icon}
                </span>
                <h3 className="mt-5 font-display text-lg font-bold text-ruby-950">{f.title}</h3>
                <p className="text-xs font-semibold tracking-widest text-ruby-400 uppercase">{f.en}</p>
                <p className="mt-2.5 text-sm leading-relaxed text-ruby-950/60">{f.desc}</p>
              </TiltCard>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}
