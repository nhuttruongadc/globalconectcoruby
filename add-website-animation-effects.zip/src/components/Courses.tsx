import { useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { Reveal, SectionHead, TiltCard } from "./shared";

const categories = [
  { id: "all", label: "Tất Cả", icon: "✦" },
  { id: "speaking", label: "Tiếng Anh Giao Tiếp", icon: "🗣️" },
  { id: "academic", label: "Tiếng Anh Học Thuật", icon: "📐" },
  { id: "exam", label: "Ôn Thi", icon: "📝" },
  { id: "chinese", label: "Tiếng Trung", icon: "🀄" },
  { id: "special", label: "Đặc Biệt", icon: "💝" },
];

const courses = [
  { cat: "speaking", catLabel: "Tiếng Anh Giao Tiếp", title: "Giao Tiếp Cơ Bản", desc: "Xây dựng phản xạ, phát âm chuẩn. Nền tảng cho người mới bắt đầu.", icon: "🌱", grad: "from-emerald-500 to-teal-600" },
  { cat: "speaking", catLabel: "Tiếng Anh Giao Tiếp", title: "Giao Tiếp Nâng Cao", desc: "Diễn đạt lưu loát, tự nhiên. Dành cho người có nền tảng muốn nâng cao.", icon: "🚀", grad: "from-sky-500 to-blue-600" },
  { cat: "speaking", catLabel: "Tiếng Anh Giao Tiếp", title: "Thuyết Trình Tiếng Anh", desc: "Public speaking và thuyết phục hiệu quả trước đám đông.", icon: "🎤", grad: "from-violet-500 to-purple-600" },
  { cat: "academic", catLabel: "Tiếng Anh Học Thuật", title: "Ngữ Pháp Chuyên Sâu", desc: "Hệ thống từ căn bản đến nâng cao, vững nền cho mọi kỳ thi.", icon: "📖", grad: "from-amber-500 to-orange-600" },
  { cat: "academic", catLabel: "Tiếng Anh Học Thuật", title: "Lấy Lại Căn Bản", desc: "Dành cho người mất gốc, xây dựng lại nền tảng từ đầu.", icon: "🔁", grad: "from-cyan-500 to-sky-600" },
  { cat: "exam", catLabel: "Ôn Thi", title: "THPT Quốc Gia", desc: "Chiến lược + luyện đề cụ thể, tối ưu điểm số kỳ thi.", icon: "🎓", grad: "from-rose-500 to-ruby-600" },
  { cat: "exam", catLabel: "Ôn Thi", title: "IELTS / TOEIC / Vstep", desc: "Ôn luyện 4 kỹ năng chuyên sâu theo chuẩn quốc tế.", icon: "🌍", grad: "from-indigo-500 to-blue-700" },
  { cat: "chinese", catLabel: "Tiếng Trung", title: "Tiếng Trung Giao Tiếp", desc: "Phát âm chuẩn, hội thoại thực tế. Từ nhập môn đến HSK 1–4.", icon: "🐉", grad: "from-red-500 to-rose-700" },
  { cat: "special", catLabel: "Chương Trình Đặc Biệt", title: "Tiếng Việt cho Cô Dâu", desc: "Dạy tiếng Trung cơ bản cho cô dâu Việt Nam & tiếng Việt cho người Trung Quốc.", icon: "💒", grad: "from-pink-500 to-rose-500" },
];

export default function Courses() {
  const [active, setActive] = useState("all");
  const filtered = active === "all" ? courses : courses.filter((c) => c.cat === active);

  return (
    <section id="courses" className="relative bg-white py-24">
      <div className="pointer-events-none absolute top-20 -right-32 h-96 w-96 rounded-full bg-ruby-50 blur-3xl" />
      <div className="relative mx-auto max-w-7xl px-5 lg:px-8">
        <SectionHead
          kicker="Danh Mục Khóa Học"
          title="Các Khóa Học"
          sub="Đa dạng khóa học từ tiếng Anh giao tiếp, học thuật đến tiếng Trung và luyện thi chuyên sâu."
        />

        {/* Tabs */}
        <Reveal>
          <div className="mb-12 flex flex-wrap justify-center gap-2.5">
            {categories.map((c) => (
              <button
                key={c.id}
                onClick={() => setActive(c.id)}
                className={`relative rounded-full px-5 py-2.5 text-sm font-bold transition-all duration-300 ${
                  active === c.id
                    ? "text-white shadow-lg shadow-ruby-500/30"
                    : "bg-ruby-50 text-ruby-800 ring-1 ring-ruby-100 hover:bg-ruby-100"
                }`}
              >
                {active === c.id && (
                  <motion.span
                    layoutId="courseTab"
                    className="absolute inset-0 rounded-full bg-gradient-to-r from-ruby-600 to-ruby-500"
                    transition={{ type: "spring", stiffness: 350, damping: 30 }}
                  />
                )}
                <span className="relative">{c.icon} {c.label}</span>
              </button>
            ))}
          </div>
        </Reveal>

        {/* Grid */}
        <motion.div layout className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
          <AnimatePresence mode="popLayout">
            {filtered.map((c, i) => (
              <motion.div
                key={c.title}
                layout
                initial={{ opacity: 0, scale: 0.85, y: 24 }}
                animate={{ opacity: 1, scale: 1, y: 0 }}
                exit={{ opacity: 0, scale: 0.85 }}
                transition={{ duration: 0.4, delay: i * 0.04, ease: [0.22, 1, 0.36, 1] }}
              >
                <TiltCard className="group relative h-full overflow-hidden rounded-3xl border border-ruby-100 bg-white p-7 shadow-lg shadow-ruby-900/5 hover:shadow-2xl hover:shadow-ruby-500/15">
                  <div className={`absolute inset-x-0 top-0 h-1.5 bg-gradient-to-r ${c.grad}`} />
                  <span
                    className={`inline-grid h-14 w-14 place-items-center rounded-2xl bg-gradient-to-br ${c.grad} text-2xl shadow-lg transition-transform duration-500 group-hover:-rotate-6 group-hover:scale-110`}
                  >
                    {c.icon}
                  </span>
                  <p className="mt-5 text-[11px] font-bold tracking-[0.15em] text-ruby-500 uppercase">{c.catLabel}</p>
                  <h3 className="mt-1.5 font-display text-xl font-bold text-ruby-950">{c.title}</h3>
                  <p className="mt-2.5 text-sm leading-relaxed text-ruby-950/60">{c.desc}</p>
                  <span className="mt-5 inline-flex items-center gap-1.5 text-sm font-bold text-ruby-600 transition-all duration-300 group-hover:gap-3 group-hover:text-ruby-700">
                    Đăng ký ngay <span>→</span>
                  </span>
                </TiltCard>
              </motion.div>
            ))}
          </AnimatePresence>
        </motion.div>
      </div>
    </section>
  );
}
