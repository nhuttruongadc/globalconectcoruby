import { motion } from "framer-motion";
import { Reveal, Sparkles } from "./shared";

export default function Founder() {
  return (
    <section id="founder" className="relative overflow-hidden bg-gradient-to-b from-white via-ruby-50/60 to-white py-24">
      <Sparkles count={10} className="opacity-60" />
      <div className="relative mx-auto max-w-7xl px-5 lg:px-8">
        <div className="grid items-center gap-14 lg:grid-cols-2">
          {/* Photo */}
          <Reveal>
            <div className="relative mx-auto max-w-md">
              <motion.div
                animate={{ rotate: [0, 3, 0, -3, 0] }}
                transition={{ duration: 12, repeat: Infinity, ease: "easeInOut" }}
                className="absolute -inset-4 rounded-[2.5rem] bg-gradient-to-br from-ruby-400/40 via-rose-300/40 to-amber-300/40 blur-xl"
              />
              <div className="relative overflow-hidden rounded-[2.5rem] shadow-2xl shadow-ruby-900/25 ring-4 ring-white">
                <img
                  src="/images/founder.jpg"
                  alt="Cô Phạm Thị Ngọc Diễm – Mrs. Ruby"
                  className="w-full object-cover transition-transform duration-[3s] hover:scale-105"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-ruby-950/35 via-transparent to-transparent" />
              </div>

              <motion.a
                href="tel:0344878674"
                whileHover={{ scale: 1.06 }}
                whileTap={{ scale: 0.96 }}
                animate={{ y: [0, -8, 0] }}
                transition={{ duration: 4, repeat: Infinity, ease: "easeInOut" }}
                className="absolute -right-4 -bottom-5 flex items-center gap-2.5 rounded-2xl bg-white px-5 py-3.5 shadow-xl shadow-ruby-900/20"
              >
                <span className="grid h-10 w-10 place-items-center rounded-full bg-green-100 text-lg">📱</span>
                <span>
                  <span className="block text-[10px] font-bold tracking-widest text-ruby-500 uppercase">Điện thoại / Zalo</span>
                  <span className="block text-sm font-extrabold text-ruby-950">0344 878 674</span>
                </span>
              </motion.a>
            </div>
          </Reveal>

          {/* Info */}
          <div>
            <Reveal>
              <span className="inline-flex items-center gap-2 rounded-full bg-ruby-50 px-4 py-1.5 text-xs font-bold tracking-widest text-ruby-700 uppercase ring-1 ring-ruby-200">
                <span>✦</span> Đội Ngũ Giảng Viên
              </span>
            </Reveal>
            <Reveal delay={0.1}>
              <h2 className="mt-5 font-display text-4xl font-extrabold text-ruby-950 sm:text-5xl">Phạm Thị Ngọc Diễm</h2>
              <p className="mt-2 text-sm font-bold tracking-widest text-ruby-600 uppercase">
                Mrs. Ruby · Giảng Viên Tiếng Anh & Tiếng Trung · Người Sáng Lập
              </p>
            </Reveal>
            <Reveal delay={0.2}>
              <blockquote className="mt-7 border-l-4 border-ruby-500 pl-5 font-display text-lg font-semibold text-ruby-900 italic">
                “Chúng tôi không chỉ dạy ngôn ngữ — chúng tôi truyền cảm hứng để học viên tin vào chính mình.”
              </blockquote>
            </Reveal>

            <div className="mt-8 grid gap-5 sm:grid-cols-2">
              <Reveal delay={0.25}>
                <motion.div
                  whileHover={{ y: -6 }}
                  className="h-full rounded-3xl border border-ruby-100 bg-white p-6 shadow-lg shadow-ruby-900/5"
                >
                  <span className="text-3xl">🎯</span>
                  <h3 className="mt-3 font-display text-lg font-bold text-ruby-950">Tầm Nhìn</h3>
                  <p className="mt-2 text-sm leading-relaxed text-ruby-950/65">
                    Trở thành chuỗi trung tâm giáo dục uy tín, giúp học sinh mọi lứa tuổi ở nông thôn và thành thị nắm vững kiến thức và phát triển kỹ năng.
                  </p>
                </motion.div>
              </Reveal>
              <Reveal delay={0.35}>
                <motion.div
                  whileHover={{ y: -6 }}
                  className="h-full rounded-3xl border border-ruby-100 bg-white p-6 shadow-lg shadow-ruby-900/5"
                >
                  <span className="text-3xl">💡</span>
                  <h3 className="mt-3 font-display text-lg font-bold text-ruby-950">Sứ Mệnh</h3>
                  <p className="mt-2 text-sm leading-relaxed text-ruby-950/65">
                    Cung cấp môi trường học tập khác biệt, xây dựng thương hiệu giáo dục đáng tin cậy mà học sinh và phụ huynh luôn nhớ đến.
                  </p>
                </motion.div>
              </Reveal>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
