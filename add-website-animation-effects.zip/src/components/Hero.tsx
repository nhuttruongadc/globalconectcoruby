import { motion } from "framer-motion";
import { Counter, Sparkles } from "./shared";

const tags = ["🎯 Tận Tâm", "💎 Khác Biệt", "🌟 Vui Vẻ", "📚 Cá Nhân Hóa"];

const stats = [
  { value: 1, suffix: ":1", label: "Lớp Cá Nhân" },
  { value: 2, suffix: "", label: "Phòng Học" },
  { value: 40, suffix: "+", label: "Học Sinh/Buổi" },
  { value: 100, suffix: "%", label: "Tận Tâm" },
];

const words = ["Hello! 👋", "你好 Ní Hão", "A Global Connect", "Language Power ✦"];

export default function Hero() {
  return (
    <section id="top" className="relative flex min-h-screen items-center overflow-hidden bg-gradient-to-br from-ruby-100 via-rose-50 to-rose-100 pt-24 pb-16">
      {/* decorative glows */}
      <div className="pointer-events-none absolute -top-40 -left-40 h-[480px] w-[480px] rounded-full bg-ruby-300/50 blur-[120px]" />
      <div className="pointer-events-none absolute -right-32 bottom-0 h-[420px] w-[420px] rounded-full bg-rose-300/60 blur-[110px]" />
      <Sparkles count={18} />

      <div className="relative mx-auto grid w-full max-w-7xl items-center gap-14 px-5 lg:grid-cols-2 lg:px-8">
        {/* Left copy */}
        <div>
          <motion.span
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.15, duration: 0.7 }}
            className="inline-flex items-center gap-2 rounded-full bg-white/80 px-4 py-2 text-xs font-bold tracking-[0.2em] uppercase text-ruby-700 ring-1 ring-ruby-200 backdrop-blur"
          >
            <span className="animate-sparkle">✦</span> A Global Connect — Dịch Vụ Cộng Đồng
          </motion.span>

          <motion.h1
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.3, duration: 0.8, ease: [0.22, 1, 0.36, 1] }}
            className="mt-6 font-display text-4xl font-extrabold leading-[1.1] text-ruby-950 sm:text-5xl md:text-6xl"
          >
            Tiếng Anh · Tiếng Trung
            <span className="mt-2 block">
              · <span className="text-shine">Tin Học</span>
            </span>
          </motion.h1>

          <motion.p
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.45, duration: 0.8 }}
            className="mt-6 max-w-lg text-lg leading-relaxed text-ruby-950/70"
          >
            <em className="font-display text-xl not-italic text-ruby-600">
              “Ngôn ngữ là sức mạnh — Chúng tôi trao nó cho bạn.”
            </em>
          </motion.p>

          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.6, duration: 0.8 }}
            className="mt-7 flex flex-wrap gap-2.5"
          >
            {tags.map((t, i) => (
              <motion.span
                key={t}
                animate={{ y: [0, -6, 0] }}
                transition={{ duration: 3, repeat: Infinity, delay: i * 0.35, ease: "easeInOut" }}
                className="rounded-full bg-white/70 px-4 py-2 text-sm font-semibold text-ruby-800 ring-1 ring-ruby-200 backdrop-blur transition-colors hover:bg-white"
              >
                {t}
              </motion.span>
            ))}
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.75, duration: 0.8 }}
            className="mt-9 flex flex-wrap items-center gap-4"
          >
            <a
              href="#courses"
              className="group relative overflow-hidden rounded-full bg-gradient-to-r from-ruby-500 to-rose-500 px-8 py-4 text-base font-bold text-white shadow-xl shadow-ruby-500/30 transition-all duration-300 hover:scale-105"
            >
              <span className="relative z-10">Khám Phá Khóa Học →</span>
              <span className="absolute inset-0 -translate-x-full bg-gradient-to-r from-transparent via-white/30 to-transparent transition-transform duration-700 group-hover:translate-x-full" />
            </a>
            <a
              href="#contact"
              className="rounded-full px-8 py-4 text-base font-bold text-ruby-800 ring-2 ring-ruby-300 backdrop-blur transition-all duration-300 hover:scale-105 hover:bg-white/80 hover:ring-ruby-400"
            >
              Đăng Ký Học
            </a>
          </motion.div>
        </div>

        {/* Right image */}
        <motion.div
          initial={{ opacity: 0, scale: 0.9, x: 40 }}
          animate={{ opacity: 1, scale: 1, x: 0 }}
          transition={{ delay: 0.4, duration: 1, ease: [0.22, 1, 0.36, 1] }}
          className="relative"
        >
          <div className="relative overflow-hidden rounded-[2rem] border-4 border-white shadow-2xl shadow-ruby-900/25">
            <img
              src="/images/hero.jpg"
              alt="Lớp học tiếng Anh tại CO RUBY"
              className="h-full w-full object-cover"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-ruby-900/40 via-transparent to-transparent" />
          </div>

          {/* floating language card */}
          <motion.div
            animate={{ y: [0, -12, 0], rotate: [-2, 2, -2] }}
            transition={{ duration: 5, repeat: Infinity, ease: "easeInOut" }}
            className="absolute -left-5 top-8 rounded-2xl bg-white/95 px-5 py-3 shadow-xl shadow-ruby-900/15 backdrop-blur"
          >
            <p className="text-xs font-semibold tracking-wide text-ruby-500 uppercase">Hôm nay bạn học</p>
            <p className="font-display text-xl font-bold text-ruby-950">
              {words[Math.floor((Date.now() / 4000) % words.length)]}
            </p>
          </motion.div>

          <motion.div
            animate={{ y: [0, 10, 0] }}
            transition={{ duration: 6, repeat: Infinity, delay: 1, ease: "easeInOut" }}
            className="absolute -right-4 bottom-24 flex items-center gap-3 rounded-2xl bg-white/95 px-5 py-3.5 shadow-xl shadow-ruby-900/15 backdrop-blur"
          >
            <span className="grid h-10 w-10 place-items-center rounded-full bg-ruby-100 text-lg">🏆</span>
            <div>
              <p className="text-sm font-bold text-ruby-950">2 Giải Nhất</p>
              <p className="text-xs text-ruby-950/60">Hùng biện & Violympic</p>
            </div>
          </motion.div>
        </motion.div>
      </div>

      {/* Stats bar */}
      <motion.div
        initial={{ opacity: 0, y: 50 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.9, duration: 0.8 }}
        className="absolute inset-x-0 bottom-0"
      >
        <div className="mx-auto max-w-6xl px-5 pb-8">
          <div className="grid grid-cols-2 gap-px overflow-hidden rounded-2xl bg-white shadow-2xl shadow-ruby-900/10 ring-1 ring-white md:grid-cols-4">
            {stats.map((s, i) => (
              <motion.div
                key={s.label}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 1 + i * 0.12 }}
                className="bg-white/70 px-6 py-5 text-center transition-colors duration-300 hover:bg-white"
              >
                <p className="font-display text-3xl font-extrabold text-ruby-600 sm:text-4xl">
                  <Counter to={s.value} suffix={s.suffix} />
                </p>
                <p className="mt-1 text-xs font-semibold tracking-widest text-ruby-950/55 uppercase">{s.label}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </motion.div>
    </section>
  );
}
